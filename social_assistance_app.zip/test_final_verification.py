from app import app
import word_service, database

client = app.test_client()
with client.session_transaction() as sess:
    sess['user'] = {'id': 1, 'username': 'superadmin', 'full_name': 'soeunchim', 'role': 'SuperAdmin'}

# 1. Test Dashboard HTML has favicon and navbar logo
res_dash = client.get('/')
assert res_dash.status_code == 200
html_dash = res_dash.data.decode('utf-8')
assert 'rel="icon"' in html_dash
assert 'images/logo.png' in html_dash
assert '<img src="/static/images/logo.png"' in html_dash or '<img src="' in html_dash
print('1. Dashboard Favicon & Navbar Logo PASSED!')

# 2. Test Settings page has Logo Management
res_set = client.get('/settings')
assert res_set.status_code == 200
html_set = res_set.data.decode('utf-8')
assert 'update_logo' in html_set
assert 'logo-preview' in html_set
assert 'reset_logo' in html_set
print('2. Settings Logo Management Card PASSED!')

# 3. Test Word Export
conn = database.get_db_connection()
st = dict(conn.execute('SELECT * FROM students LIMIT 1').fetchone())
sch = dict(conn.execute('SELECT * FROM school_settings WHERE id=1').fetchone())
conn.close()

word_service.generate_certificate_docx(st, sch, 'data/test_final_verify.docx')
print('3. Word docx generation PASSED!')
