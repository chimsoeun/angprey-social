import unittest
import database
import excel_service
import word_service
import os

class SystemSmokeTest(unittest.TestCase):
    def setUp(self):
        database.init_db()

    def test_database_connection(self):
        conn = database.get_db_connection()
        cur = conn.cursor()
        users = cur.execute('SELECT * FROM users').fetchall()
        self.assertGreaterEqual(len(users), 3)

        students = cur.execute('SELECT * FROM students').fetchall()
        self.assertGreaterEqual(len(students), 1)

        years = cur.execute('SELECT * FROM academic_years').fetchall()
        self.assertGreaterEqual(len(years), 4)

        school = cur.execute('SELECT * FROM school_settings LIMIT 1').fetchone()
        self.assertIsNotNone(school)
        self.assertEqual(school['school_name'], 'វិទ្យាល័យ ហ៊ុន សែន អង្គប្រីយ៍')
        conn.close()

    def test_excel_export(self):
        conn = database.get_db_connection()
        students = [dict(r) for r in conn.cursor().execute('SELECT * FROM students').fetchall()]
        conn.close()

        export_path = os.path.join(database.DB_DIR, 'exports', 'test_export.xlsx')
        res = excel_service.export_students_to_excel(students, export_path)
        self.assertTrue(os.path.exists(res))
        self.assertGreater(os.path.getsize(res), 1000)

    def test_word_certificate(self):
        conn = database.get_db_connection()
        student = dict(conn.cursor().execute('SELECT * FROM students LIMIT 1').fetchone())
        school = dict(conn.cursor().execute('SELECT * FROM school_settings LIMIT 1').fetchone())
        conn.close()

        out_path = os.path.join(database.DB_DIR, 'exports', 'test_cert_output.docx')
        res = word_service.generate_certificate_docx(student, school, out_path)
        self.assertTrue(os.path.exists(res))
        self.assertGreater(os.path.getsize(res), 5000)

if __name__ == '__main__':
    unittest.main()
