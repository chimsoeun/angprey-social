﻿$word = New-Object -ComObject Word.Application
$word.Visible = $false
try {
    $doc = $word.Documents.Open('D:\វិ.ហ.ស អង្គប្រីយ៍\កម្មវិធីជំនួយសង្គម\data\test_final_verify.docx')
    $pages = $doc.ComputeStatistics(2)
    Write-Host "WORD_PAGES:$pages"
    $doc.Close([ref]$false)
} finally {
    $word.Quit()
}
