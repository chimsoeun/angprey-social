import webbrowser
import threading
import time
import os
import sys

def open_browser():
    time.sleep(1.5)
    webbrowser.open('http://127.0.0.1:5000')

if __name__ == '__main__':
    from app import app
    print("=" * 60)
    print("  ប្រព័ន្ធគ្រប់គ្រងកម្មវិធីជំនួយសង្គម")
    print("  វិទ្យាល័យ ហ៊ុន សែន អង្គប្រីយ៍")
    print("  Server is starting on http://127.0.0.1:5000")
    print("=" * 60)

    # Launch browser automatically
    threading.Thread(target=open_browser, daemon=True).start()

    # Run app
    app.run(host='127.0.0.1', port=5000, debug=False)
